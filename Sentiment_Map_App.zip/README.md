
# 📍 Interactive Sentiment Map (Streamlit App)

This app displays an interactive map of sentiment about locations in Edinburgh based on historical literary references.

## 🛠 How to Use It

1. Install Streamlit and dependencies:
```bash
pip install streamlit pandas folium streamlit-folium
```

2. Run the app:
```bash
streamlit run app.py
```

3. The app will open in your browser at http://localhost:8501

## 🌍 Optional: Deploy Online (Free)
Use [https://streamlit.io/cloud](https://streamlit.io/cloud) to upload this project and make it accessible online.

## 📂 Files Included
- `app.py` — the main Streamlit app
- `Completed Sentiments(Sheet 1).csv` — your dataset
